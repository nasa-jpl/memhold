# Software SEE Testing for Commodity SoCs
This tool detects and locates potential stuck or sticky bits in DRAM. The default
configuration is meant for the Snapdragon 801 SoC on the Mars 2020 HBS, but can be
easily adapted to support other chipsets.

**TODO:** full run on frank snapdragon and edit memory during a super long `sleep()`.
The memory file should be accessible as root on `/dev/mem`. If busybox is available,
`busybox devmem <some address> w <new value>` should be able to change the memory. A
list of physicall addresses mapped to the process should be in `/proc/PID/maps`. but
not 100% sure how we can get the physical address of some address that is in the
`malloc`-ed space. Probabilisitcally we have a pretty good chance of hitting it if
we're allocating close to 1G though.

## Usage
```bash
radiation_test mbs_to_alloc iterations sleep_time max_errors_out out_file_template
```

## Requirements
* CMake 3.16 or newer
* GCC/LLVM toolchain with C++14 support

## Building
This project is meant to be built as part of HCE-FSW. Follow the build instructions
in the M20-HCE/HCE-FSW repo. The `wanghaod-rad-hardening` branch keeps track of this
repo. The `radiation_test` target will build and compile a minimal binary for HBS
(~162KB gzip-ed).

## Design
The program reserves `memory_size` megabytes of memory using `malloc` and writes an
array of different repeating pattern to the reserved locations. After a user-specified
wait time, the memory location is then read back again, and the read pattern compared
to the written one. Errors are then logged to `<output_file_template>.csv` in a CSV
format. Kernel page information is also saved to allow logged virtual memory addresses
to be converted to physical memory addresses. `mlock` is used to ensure that no memory
is swapped out, while `__clear__cache` calls in between reads and writes ensure that
data is read from DRAM and not the intermediate caches.

## Previous Testing
### On Snapdragon
Basic process: compiled with HCE-FSW build process (see `wanghaod-rad-hardening` branch
[here](https://github.jpl.nasa.gov/M20-HCE/hce-fsw/blob/wanghaod-rad-hardening/)). Moved
the `radiation_test` binary to `/img` directory on Snapdragon testbed on `frank` and ran
on command line from `adb shell`. Items tested:

* CSV and error file output correctly notes no errors and start time
* `mlock()`, `__clear_cache()` working correctly
* Saving pagemap files works correctly

### On x86
Basic process: build with HCE-FSW as above, but with the `build` target instead of
`build_cross`. Items tested:

* CSV and error file output correctly notes no errors and start time
* `mlock()`, `__clear_cache()` working correctly
* CSV correctly records an error when comparison is manually failed via GDB

## Example CSV output
```csv
iter,time,virtual_addr,actual,expected
0,11741703296,0,0,0
1,11741733527,0x7ffff7b0b010,0x5555455555555555,0x5555555555555555
